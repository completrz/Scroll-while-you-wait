// Runs on AI chat sites. Watches for the "Stop generating" control and tells
// the background worker when a response starts and finishes.
(() => {
  if (window.top !== window) return;

  // If this script is injected again (extension reloaded or updated), the newest
  // copy takes over and older copies shut themselves down.
  const INSTANCE = Math.random().toString(36).slice(2);
  window.__rwwInstance = INSTANCE;
  const superseded = () => window.__rwwInstance !== INSTANCE;

  const START_DELAY = 700; // must look "generating" this long before we report it
  const STOP_DELAY = 1800; // must look "idle" this long before we report done
  const CHECK_THROTTLE = 250; // max DOM re-check rate while the page streams text
  const SAFETY_POLL = 1000; // backstop in case a mutation is missed

  // Per-site selectors for the stop button. Add or fix entries here if a site
  // changes its markup. The generic label check below is the fallback.
  const SITE_SELECTORS = {
    'chatgpt.com': [
      'button[data-testid="stop-button"]',
      'button[aria-label="Stop streaming"]'
    ],
    'chat.openai.com': [
      'button[data-testid="stop-button"]',
      'button[aria-label="Stop streaming"]'
    ],
    'claude.ai': ['button[aria-label="Stop response"]'],
    'gemini.google.com': [
      'button[aria-label="Stop response"]',
      'button.stop',
      'mat-icon[fonticon="stop"]'
    ],
    'www.perplexity.ai': ['button[aria-label="Stop"]'],
    'copilot.microsoft.com': [
      'button[aria-label="Stop Responding"]',
      'button[data-testid="stop-button"]'
    ],
    'grok.com': ['button[aria-label="Stop model response"]'],
    'chat.deepseek.com': [],
    'chat.mistral.ai': ['button[aria-label="Stop"]']
  };

  const siteSelectors = SITE_SELECTORS[location.hostname] || [];

  const GENERIC_CANDIDATES = [
    'button[aria-label*="stop" i]',
    'button[title*="stop" i]',
    '[role="button"][aria-label*="stop" i]',
    'button[data-testid*="stop" i]'
  ].join(',');

  // "Stop", "Stop generating", "Stop response", "Stop responding", ...
  // Deliberately does NOT match "Stop recording" / "Stop dictation".
  const STOP_LABEL =
    /^stop(\s+(generating|generation|streaming|response|responding|model response|answering|thinking))?\.?$/i;
  const STOP_TESTID = /(^|[-_])stop([-_]|$)/i;

  function isVisible(el) {
    return el.getClientRects().length > 0 && !el.disabled;
  }

  function isGenerating() {
    for (const sel of siteSelectors) {
      const el = document.querySelector(sel);
      if (el && isVisible(el)) return true;
    }
    for (const el of document.querySelectorAll(GENERIC_CANDIDATES)) {
      const label = (el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
      const testId = el.getAttribute('data-testid') || '';
      if ((STOP_LABEL.test(label) || STOP_TESTID.test(testId)) && isVisible(el)) return true;
    }
    return false;
  }

  let reported = false;
  let startTimer = null;
  let stopTimer = null;

  function report(generating) {
    reported = generating;
    try {
      chrome.runtime.sendMessage({ type: 'ai-state', generating });
    } catch (_) {
      // Extension was reloaded or updated; this content script is orphaned.
    }
  }

  function update() {
    if (superseded()) return shutdown();
    if (isGenerating()) {
      clearTimeout(stopTimer);
      stopTimer = null;
      if (!reported && !startTimer) {
        startTimer = setTimeout(() => {
          startTimer = null;
          if (isGenerating()) report(true);
        }, START_DELAY);
      }
    } else {
      clearTimeout(startTimer);
      startTimer = null;
      if (reported && !stopTimer) {
        stopTimer = setTimeout(() => {
          stopTimer = null;
          if (!isGenerating()) report(false);
        }, STOP_DELAY);
      }
    }
  }

  let scheduled = null;
  function schedule() {
    if (scheduled) return;
    scheduled = setTimeout(() => {
      scheduled = null;
      update();
    }, CHECK_THROTTLE);
  }

  const observer = new MutationObserver(schedule);
  observer.observe(document.documentElement, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ['aria-label', 'title', 'data-testid', 'disabled']
  });
  const pollId = setInterval(update, SAFETY_POLL);
  window.addEventListener('pagehide', () => {
    if (!superseded() && reported) report(false);
  });

  function shutdown() {
    observer.disconnect();
    clearInterval(pollId);
    clearTimeout(startTimer);
    clearTimeout(stopTimer);
    clearTimeout(scheduled);
  }

  // Lets the popup check that this tab is being watched.
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg && msg.type === 'ping' && !superseded()) {
      sendResponse({ alive: true, generating: isGenerating() });
    }
  });

  update();
})();

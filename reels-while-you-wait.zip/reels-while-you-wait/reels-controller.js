// Runs on Instagram / YouTube / TikTok. It only acts when the background worker
// says this tab is the reels window the extension opened, so your normal
// browsing on those sites is never touched.
(() => {
  if (window.top !== window) return;

  let managed = false;
  let wantPlay = false;
  let playTimer = null;
  let guardTimer = null;

  const videos = () => Array.from(document.querySelectorAll('video'));

  function visibleArea(v) {
    const r = v.getBoundingClientRect();
    const w = Math.max(0, Math.min(r.right, innerWidth) - Math.max(r.left, 0));
    const h = Math.max(0, Math.min(r.bottom, innerHeight) - Math.max(r.top, 0));
    return w * h;
  }

  function mainVideo() {
    let best = null;
    let bestArea = 0;
    for (const v of videos()) {
      const area = visibleArea(v);
      if (area > bestArea) {
        bestArea = area;
        best = v;
      }
    }
    return best;
  }

  async function tryPlay() {
    const v = mainVideo();
    if (!v || !v.paused) return;
    try {
      await v.play();
    } catch (err) {
      // Autoplay policy: sound needs a prior click. Muted playback is always allowed.
      if (err && err.name === 'NotAllowedError') {
        v.muted = true;
        try {
          await v.play();
        } catch (_) {}
      }
    }
  }

  function pauseAll() {
    for (const v of videos()) if (!v.paused) v.pause();
  }

  // Keep trying for ~10s: the first video may not be in the DOM yet.
  function startPlaying() {
    clearInterval(guardTimer);
    clearInterval(playTimer);
    let attempts = 0;
    playTimer = setInterval(() => {
      if (!managed || !wantPlay || attempts++ > 20) return clearInterval(playTimer);
      const v = mainVideo();
      if (v && !v.paused) return clearInterval(playTimer);
      tryPlay();
    }, 500);
    tryPlay();
  }

  // Pause now, then keep pausing for a moment so the site can't auto-resume.
  // After that you are free to press play yourself.
  function startPausing() {
    clearInterval(playTimer);
    clearInterval(guardTimer);
    pauseAll();
    const until = Date.now() + 2500;
    guardTimer = setInterval(() => {
      if (!managed || wantPlay || Date.now() > until) return clearInterval(guardTimer);
      pauseAll();
    }, 250);
  }

  // ---- auto-scroll: move to the next reel when the current one ends or loops ----

  let autoScroll = true;
  try {
    chrome.storage.local.get({ autoScroll: true }).then((s) => (autoScroll = s.autoScroll));
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.autoScroll) autoScroll = changes.autoScroll.newValue;
    });
  } catch (_) {}

  function scrollContainerOf(el) {
    while (el && el !== document.documentElement) {
      if (el.scrollHeight > el.clientHeight + 10 && /(auto|scroll)/.test(getComputedStyle(el).overflowY)) return el;
      el = el.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  function advance() {
    const before = mainVideo();
    // First choice: the ArrowDown shortcut all three sites support.
    const key = (type) =>
      new KeyboardEvent(type, { key: 'ArrowDown', code: 'ArrowDown', keyCode: 40, which: 40, bubbles: true, cancelable: true });
    const target = document.activeElement || document.body;
    target.dispatchEvent(key('keydown'));
    target.dispatchEvent(key('keyup'));
    // Fallback: if the reel didn't change, scroll the feed by one screen.
    setTimeout(() => {
      if (!before || mainVideo() !== before) return;
      scrollContainerOf(before).scrollBy({ top: innerHeight, behavior: 'smooth' });
    }, 700);
    // Make sure the next reel is actually playing.
    setTimeout(() => {
      if (managed && wantPlay) startPlaying();
    }, 1300);
  }

  let watched = null;
  let lastTime = 0;
  let cooldownUntil = 0;
  setInterval(() => {
    if (!managed || !wantPlay || !autoScroll) return;
    const v = mainVideo();
    if (!v) return;
    if (v !== watched) {
      watched = v;
      lastTime = v.currentTime;
      return;
    }
    const looped = lastTime > 1.5 && v.currentTime < lastTime - 0.75;
    lastTime = v.currentTime;
    if ((v.ended || looped) && Date.now() > cooldownUntil) {
      cooldownUntil = Date.now() + 2500;
      advance();
    }
  }, 300);

  function apply() {
    if (!managed) return;
    wantPlay ? startPlaying() : startPausing();
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    if (msg.type === 'reels-play') {
      managed = true;
      wantPlay = true;
      apply();
    } else if (msg.type === 'reels-pause') {
      managed = true;
      wantPlay = false;
      apply();
    }
  });

  // On load, ask whether this tab is the managed reels tab.
  try {
    chrome.runtime
      .sendMessage({ type: 'reels-hello' })
      .then((res) => {
        if (res && res.managed) {
          managed = true;
          wantPlay = !!res.shouldPlay;
          apply();
        }
      })
      .catch(() => {});
  } catch (_) {}
})();

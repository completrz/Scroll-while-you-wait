// Reels While You Wait: service worker.
// Tracks which AI tabs are generating, and opens / plays / pauses one reels window.

const DEFAULT_SETTINGS = { enabled: true, source: 'instagram', focusOnStart: true, autoMinimize: true };

const SOURCES = {
  instagram: { name: 'Instagram Reels', url: 'https://www.instagram.com/reels/' },
  youtube: { name: 'YouTube Shorts', url: 'https://www.youtube.com/shorts' },
  tiktok: { name: 'TikTok', url: 'https://www.tiktok.com/foryou' }
};

const WINDOW_SIZE = { width: 420, height: 820 };

// ---- state -----------------------------------------------------------------
// Service workers get shut down when idle, so state lives in storage.session.
// state = { generating: { [tabId]: true }, reels: { tabId, windowId } | null, forced: boolean }

async function getState() {
  const { state } = await chrome.storage.session.get('state');
  return { generating: {}, reels: null, forced: false, ...(state || {}) };
}
const saveState = (state) => chrome.storage.session.set({ state });
const getSettings = () => chrome.storage.local.get(DEFAULT_SETTINGS);

const anyGenerating = (state) => Object.keys(state.generating).length > 0;
const wantsPlay = (state, settings) => settings.enabled && (state.forced || anyGenerating(state));

// Every handler runs through one queue so concurrent events can't race on state.
let queue = Promise.resolve();
const enqueue = (job) => (queue = queue.then(job).catch((e) => console.error('[Reels While You Wait]', e)));

const lastNormalWindowId = () =>
  chrome.windows
    .getLastFocused({ windowTypes: ['normal'] })
    .then((w) => w.id)
    .catch(() => undefined);

// ---- window placement ------------------------------------------------------

function centerInside(b, d) {
  const cx = b.left + b.width / 2;
  const cy = b.top + b.height / 2;
  const r = d.bounds;
  return cx >= r.left && cx < r.left + r.width && cy >= r.top && cy < r.top + r.height;
}

async function pickBounds(originWindowId) {
  let displays = [];
  try {
    displays = await chrome.system.display.getInfo();
  } catch (_) {}

  // Reuse wherever the user last dragged the reels window.
  const { reelsBounds } = await chrome.storage.local.get('reelsBounds');
  if (reelsBounds && displays.some((d) => centerInside(reelsBounds, d))) return reelsBounds;

  const bounds = { width: WINDOW_SIZE.width, height: WINDOW_SIZE.height };
  if (!displays.length) return bounds;

  const origin = originWindowId != null ? await chrome.windows.get(originWindowId).catch(() => null) : null;
  const display =
    (origin && displays.find((d) => centerInside(origin, d))) ||
    displays.find((d) => d.isPrimary) ||
    displays[0];
  const wa = display.workArea;
  bounds.width = Math.min(WINDOW_SIZE.width, wa.width);
  bounds.height = Math.min(WINDOW_SIZE.height, wa.height);
  bounds.left = wa.left + wa.width - bounds.width; // right edge of the screen
  bounds.top = wa.top + Math.round((wa.height - bounds.height) / 2);
  return bounds;
}

// ---- play / pause ----------------------------------------------------------

async function startReels(state, settings, originWindowId) {
  const src = SOURCES[settings.source] || SOURCES.instagram;
  const tab = state.reels ? await chrome.tabs.get(state.reels.tabId).catch(() => null) : null;

  if (!tab) {
    const bounds = await pickBounds(originWindowId);
    const win = await chrome.windows.create({
      url: src.url,
      type: 'popup',
      focused: !!settings.focusOnStart, // default: don't steal focus from your chat
      ...bounds
    });
    state.reels = { tabId: win.tabs[0].id, windowId: win.id };
    await saveState(state);
    return; // the page's content script asks for its state when it loads
  }

  const win = await chrome.windows.get(tab.windowId).catch(() => null);
  if (win) {
    // The window was left open (paused) and may be minimized or buried behind
    // the chat window, so surface it every time a response starts.
    if (win.state === 'minimized') {
      await chrome.windows.update(win.id, { state: 'normal' }).catch(() => {});
    }
    await chrome.windows.update(win.id, { focused: true }).catch(() => {});
    // Raising a window needs focus. Hand it straight back so you can keep typing.
    if (!settings.focusOnStart && originWindowId != null) {
      await chrome.windows.update(originWindowId, { focused: true }).catch(() => {});
    }
  }
  chrome.tabs.sendMessage(tab.id, { type: 'reels-play' }).catch(() => {});
}

async function pauseReels(state, settings) {
  if (!state.reels) return;
  const alive = await chrome.tabs
    .get(state.reels.tabId)
    .then(() => true)
    .catch(() => false);
  if (!alive) {
    state.reels = null;
    await saveState(state);
    return;
  }
  await chrome.tabs.sendMessage(state.reels.tabId, { type: 'reels-pause' }).catch(() => {});
  if (settings.autoMinimize && !state.forced) {
    const win = await chrome.windows.get(state.reels.windowId).catch(() => null);
    if (win && win.state === 'normal') {
      await chrome.windows.update(win.id, { state: 'minimized' }).catch(() => {});
    }
  }
}

async function reconcile(state, originWindowId) {
  const settings = await getSettings();
  if (wantsPlay(state, settings)) await startReels(state, settings, originWindowId);
  else await pauseReels(state, settings);
}

// ---- messages --------------------------------------------------------------

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg && msg.type) {
    case 'ai-state': {
      const tab = sender.tab;
      if (!tab) return;
      enqueue(async () => {
        const state = await getState();
        if (msg.generating) state.generating[tab.id] = true;
        else delete state.generating[tab.id];
        await saveState(state);
        await reconcile(state, tab.windowId);
      });
      return;
    }

    case 'reels-hello': {
      enqueue(async () => {
        try {
          const state = await getState();
          const settings = await getSettings();
          const managed = !!(sender.tab && state.reels && state.reels.tabId === sender.tab.id);
          sendResponse({ managed, shouldPlay: managed && wantsPlay(state, settings) });
        } catch (_) {
          sendResponse({ managed: false, shouldPlay: false });
        }
      });
      return true; // async response
    }

    case 'get-status': {
      enqueue(async () => {
        const state = await getState();
        const settings = await getSettings();
        const reelsOpen = state.reels
          ? await chrome.tabs
              .get(state.reels.tabId)
              .then(() => true)
              .catch(() => false)
          : false;
        sendResponse({
          enabled: settings.enabled,
          source: (SOURCES[settings.source] || SOURCES.instagram).name,
          generating: Object.keys(state.generating).length,
          forced: !!state.forced,
          reelsOpen,
          playing: wantsPlay(state, settings)
        });
      });
      return true;
    }

    case 'force': {
      // Manual play / pause from the popup.
      enqueue(async () => {
        const state = await getState();
        const originId = await lastNormalWindowId();
        if (msg.on) {
          state.forced = true;
        } else {
          state.forced = false;
          state.generating = {}; // also clears a stuck "generating" flag
        }
        await saveState(state);
        await reconcile(state, originId);
        sendResponse({ ok: true });
      });
      return true;
    }
  }
});

// ---- cleanup ---------------------------------------------------------------

chrome.tabs.onRemoved.addListener((tabId) =>
  enqueue(async () => {
    const state = await getState();
    const wasGenerating = !!state.generating[tabId];
    const wasReels = !!(state.reels && state.reels.tabId === tabId);
    if (!wasGenerating && !wasReels) return;
    if (wasGenerating) delete state.generating[tabId];
    if (wasReels) state.reels = null; // closed on purpose: don't pop it back open
    await saveState(state);
    if (wasGenerating) await reconcile(state);
  })
);

// A full page load in an AI tab kills its content script, so drop its flag.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status !== 'loading') return;
  enqueue(async () => {
    const state = await getState();
    if (!state.generating[tabId]) return;
    delete state.generating[tabId];
    await saveState(state);
    await reconcile(state);
  });
});

// Remember where the user puts the reels window.
chrome.windows.onBoundsChanged.addListener((win) =>
  enqueue(async () => {
    const state = await getState();
    if (state.reels && win.id === state.reels.windowId && win.state === 'normal') {
      await chrome.storage.local.set({
        reelsBounds: { left: win.left, top: win.top, width: win.width, height: win.height }
      });
    }
  })
);

// ---- settings changes ------------------------------------------------------

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !(changes.enabled || changes.source || changes.autoMinimize)) return;
  enqueue(async () => {
    const state = await getState();
    if (changes.source && state.reels) {
      const settings = await getSettings();
      const src = SOURCES[settings.source] || SOURCES.instagram;
      await chrome.tabs.update(state.reels.tabId, { url: src.url }).catch(() => {});
    }
    await reconcile(state, await lastNormalWindowId());
  });
});

// ---- seamless updates ------------------------------------------------------
// Reloading the extension orphans the detector in tabs that were already open,
// and Chrome won't inject the new copy until the page is refreshed. Do it here
// so nobody has to remember to refresh their chat tabs.

chrome.runtime.onInstalled.addListener(async () => {
  const manifest = chrome.runtime.getManifest();
  const detector = manifest.content_scripts.find((c) => c.js.includes('ai-detector.js'));
  const aiTabs = await chrome.tabs.query({ url: detector.matches }).catch(() => []);
  for (const tab of aiTabs) {
    chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['ai-detector.js'] }).catch(() => {});
  }
});

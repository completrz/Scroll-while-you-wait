const DEFAULTS = { enabled: true, source: 'instagram', focusOnStart: false, autoScroll: true };
const $ = (id) => document.getElementById(id);

let playing = false;

async function refresh() {
  let st;
  try {
    st = await chrome.runtime.sendMessage({ type: 'get-status' });
  } catch (_) {
    return;
  }
  if (!st) return;

  playing = st.playing;
  const dot = $('dot');
  dot.className = 'dot';

  if (!st.enabled) {
    $('status').textContent = 'Turned off';
    dot.classList.add('off');
  } else if (st.playing) {
    $('status').textContent = st.generating > 0 ? 'AI is generating: reels playing' : 'Playing (started manually)';
    dot.classList.add('on');
  } else {
    $('status').textContent = 'Waiting for an AI to start generating';
  }

  $('toggle').disabled = !st.enabled;
  $('toggle').textContent = st.playing ? 'Pause reels' : 'Play reels now';
}

// Asks the page in the current tab whether the detector is running there.
async function checkTab() {
  const line = $('tab');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const reply = await chrome.tabs.sendMessage(tab.id, { type: 'ping' });
    line.textContent = reply && reply.alive ? 'This tab: watching for responses ✓' : '';
  } catch (_) {
    line.textContent = 'This tab isn’t being watched. Open a supported AI site, or refresh the page.';
  }
}

async function init() {
  const s = await chrome.storage.local.get(DEFAULTS);
  $('enabled').checked = s.enabled;
  $('source').value = s.source;
  $('focus').checked = s.focusOnStart;
  $('autoscroll').checked = s.autoScroll;
  $('autoscroll').addEventListener('change', (e) => chrome.storage.local.set({ autoScroll: e.target.checked }));

  $('enabled').addEventListener('change', async (e) => {
    await chrome.storage.local.set({ enabled: e.target.checked });
    setTimeout(refresh, 150);
  });
  $('source').addEventListener('change', (e) => chrome.storage.local.set({ source: e.target.value }));
  $('focus').addEventListener('change', (e) => chrome.storage.local.set({ focusOnStart: e.target.checked }));

  $('toggle').addEventListener('click', async () => {
    $('toggle').disabled = true;
    await chrome.runtime.sendMessage({ type: 'force', on: !playing });
    setTimeout(refresh, 150);
  });

  refresh();
  checkTab();
  setInterval(refresh, 1000);
  setInterval(checkTab, 3000);
}

init();
